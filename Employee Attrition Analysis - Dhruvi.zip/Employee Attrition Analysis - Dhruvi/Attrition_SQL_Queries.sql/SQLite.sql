SELECT Age, Attrition, BusinessTravel, DailyRate, Department
FROM HREmployeeAttrition
LIMIT 5;


-- Goal: Count total number of employees in the dataset
SELECT COUNT(*) AS Total_Employees
FROM HREmployeeAttrition;

-- Goal: Count how many employees left the company (Attrition = 'Yes')
SELECT COUNT(*) AS Employees_Left
FROM HREmployeeAttrition
WHERE Attrition = 'Yes';

-- Goal: Calculate the attrition rate (% of employees who left)
SELECT 
  ROUND(
    (SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0) / COUNT(*), 
    2
  ) AS Attrition_Rate_Percentage
FROM HREmployeeAttrition;

-- Goal: Number of employees who left from each department
SELECT 
  Department, 
  COUNT(*) AS Total_Attrition
FROM HREmployeeAttrition
WHERE Attrition = 'Yes'
GROUP BY Department;


-- Goal: Calculate attrition rate (%) by department
SELECT 
  Department,
  ROUND(
    (SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0) / COUNT(*),
    2
  ) AS Attrition_Rate_Percentage
FROM HREmployeeAttrition
GROUP BY Department;


-- Goal: Attrition rate by Job Role
SELECT 
  JobRole,
  ROUND(
    (SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0) / COUNT(*),
    2
  ) AS Attrition_Rate_Percentage
FROM HREmployeeAttrition
GROUP BY JobRole
ORDER BY Attrition_Rate_Percentage DESC;


-- Goal: Attrition rate by Gender
SELECT 
  Gender,
  ROUND(
    (SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0) / COUNT(*),
    2
  ) AS Attrition_Rate_Percentage
FROM HREmployeeAttrition
GROUP BY Gender;



